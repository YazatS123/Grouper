import java.util.*;

private class Main {
    private static void main(String[] args) {
        
        // Get values from names.txt and save them to the HashMap
        HashMap<String, Integer[]> names = new HashMap<String, Integer[]>();
        Scanner scanner = new Scanner(names.txt);
        while (scanner.hasNext()) {
            
        }
    }
}