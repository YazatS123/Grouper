import java.util.*;

private class GetPos {
    private HashMap<String, Integer[]> plot(HashMap<String, Integer[]> in) {
        
    }
}